/**
 * Model Initialization File
 *
 * Configures the LLM model used throughout the course.
 *
 * Default: Anthropic claude-haiku-4-5 (fast, cheap, great for learning).
 *
 * ═══════════════════════════════════════════════════════════════════════════
 *   ⚠  IMPORTANT: install the matching package BEFORE swapping providers
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *   Provider              Package                      Installed?
 *   --------------------  ---------------------------  ---------------------
 *   Anthropic (default)   @langchain/anthropic          yes (default dep)
 *   OpenAI                @langchain/openai             yes (default dep)
 *   Ollama                @langchain/ollama             yes (default dep)
 *   AWS Bedrock           @langchain/aws               install separately
 *   Google Gemini         @langchain/google-genai       install separately
 *
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * To swap providers:
 *   1. Comment out the active model line(s) below.
 *   2. Uncomment the section for your desired provider.
 *   3. Set the provider's env vars in `.env` (see notes inline).
 */

import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

import { config } from "dotenv";
import { Agent, setGlobalDispatcher } from "undici";
import { initChatModel } from "langchain";

// Force `.env` to win over any same-named variable already exported by the
// shell (default dotenv behavior leaves pre-existing shell vars in place,
// which silently ignores this file's values).
config({ path: join(dirname(fileURLToPath(import.meta.url)), ".env"), override: true });

// Node's default global fetch (undici) connection pool serializes concurrent
// requests once it fills, causing multi-minute client-side queueing when
// several subagents call the same LLM endpoint concurrently. Widen it once here, before any model is constructed,
// so every lesson that imports this file is covered.
setGlobalDispatcher(new Agent({ connections: 64 }));

// ═══ Default Models ══════════════════════════════════════════════════════════
// Workshop default: Anthropic claude-haiku-4-5, fast and cost-effective.
// Requires ANTHROPIC_API_KEY in .env
export const model = await initChatModel("anthropic:claude-haiku-4-5", { timeout: 60_000, maxRetries: 2 });

// A more capable model for steps that need stronger reasoning
export const strongModel = await initChatModel("anthropic:claude-sonnet-5-5", { timeout: 120_000, maxRetries: 2 });

// ═══ Alternative Models (comment out default above, uncomment one below) ═════
// export const model = await initChatModel("anthropic:claude-sonnet-5-5");
// export const model = await initChatModel("openai:gpt-6-luna", { useResponsesApi: true });
// export const strongModel = await initChatModel("openai:gpt-6.1-sol", { useResponsesApi: true });

// ═══ Open-Source / Alternative Hosted Models ══════════════════════════════════

// Ollama: run models locally (no API key required)
// Install the Ollama app first: https://ollama.com
// Pull a model first, e.g.:  ollama pull qwen2.5:7b
// Note: small local models (7-8B) can mis-call tools or guess names; keep strongModel on a hosted model.
//
// export const model = await initChatModel("ollama:qwen2.5:7b");

// OpenRouter: hosted open-source models via OpenAI-compatible API
// Free models available; sign up at openrouter.ai and get an API key
// Requires OPENROUTER_API_KEY in .env
//
// import { ChatOpenAI } from "@langchain/openai";
// export const model = new ChatOpenAI({
//   model: "nvidia/nemotron-3-ultra-550b-a55b:free",
//   apiKey: process.env.OPENROUTER_API_KEY,
//   configuration: { baseURL: "https://openrouter.ai/api/v1" },
// });
